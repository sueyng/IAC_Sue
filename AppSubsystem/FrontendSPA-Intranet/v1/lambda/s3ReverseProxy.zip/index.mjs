import { S3Client, GetObjectCommand } from "@aws-sdk/client-s3";
const s3 = new S3Client();
const bucketName = process.env.S3_BUCKET_NAME;
export const handler = async (event) => {
  try {
    let filePath = event.path.substring(1); // Remove the leading '/'
  

    //check if the path ends with trailing slash
    if(filePath.endsWith('/')){
      filePath += 'index.html'; //Append index.html to the path
    }
    const params = {
      Bucket: bucketName,
      Key: filePath
    };
    let data;
    try {
      data = await s3.send(new GetObjectCommand(params));
    }
    catch (err) {
      // Serve index.html for all routes
      params.Key = 'index.html';
      data = await s3.send(new GetObjectCommand(params));
    }
    let bodyResponse = await data.Body.transformToString();
    
    return {
      statusCode: 200,
      headers: {
        'Content-Type': data.ContentType,
        'Cache-Control': 'public, max-age=3600'
      },
      body: bodyResponse,
    };
  }
  catch (err) {
    console.log("Encountered error while fetching S3 bucket: " + err);
    return {
      statusCode: 500,
      body: 'An error occurred',
    };
  }
};