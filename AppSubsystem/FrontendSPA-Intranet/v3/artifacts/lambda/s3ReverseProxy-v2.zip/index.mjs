import { S3Client, GetObjectCommand } from "@aws-sdk/client-s3";
const s3 = new S3Client();
const bucketName = process.env.S3_BUCKET_NAME;
 
export const handler = async (event) => {
  try {
    let filePath = event.path.substring(1);  // Remove leading '/'
 
    // If the path ends with a '/', serve index.html (default for directories)
    if (filePath.endsWith('/')) {
      filePath += 'index.html';
    }
 
    const params = {
      Bucket: bucketName,
      Key: filePath
    };
 
    let data;
    try {
      // Try fetching the requested file from S3
      data = await s3.send(new GetObjectCommand(params));
    } catch (err) {
      // If the file is not found, serve index.html
      params.Key = 'index.html';
      data = await s3.send(new GetObjectCommand(params));
    }
 
    const contentType = data.ContentType;
    let bodyResponse;
 
    if (contentType && contentType.startsWith('image')) {
      // If it's an image, process it as binary and base64 encode it
      bodyResponse = await streamToBuffer(data.Body);
      return {
        statusCode: 200,
        headers: {
          'Content-Type': contentType,  // Ensure this is 'image/png' for PNG images
          'Cache-Control': 'public, max-age=3600',
        },
        body: bodyResponse.toString('base64'),  // Base64 encode the image
        isBase64Encoded: true,  // Indicate binary content
      };
    } else {
      // If it's not an image, return it as normal text
      bodyResponse = await data.Body.transformToString();
      return {
        statusCode: 200,
        headers: {
          'Content-Type': contentType,
          'Cache-Control': 'public, max-age=3600',
        },
        body: bodyResponse,
      };
    }
  } catch (err) {
    console.log("Error fetching S3 object:", err);
    return {
      statusCode: 500,
      body: 'An error occurred',
    };
  }
};
 
// Helper function to convert stream to buffer for binary content
const streamToBuffer = async (stream) => {
  return new Promise((resolve, reject) => {
    const chunks = [];
    stream.on('data', chunk => chunks.push(chunk));
    stream.on('end', () => resolve(Buffer.concat(chunks)));
    stream.on('error', reject);
  });
};