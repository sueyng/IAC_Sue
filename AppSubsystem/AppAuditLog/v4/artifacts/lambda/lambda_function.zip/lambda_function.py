import json
import os
from datetime import datetime
import pyarrow as pa  # pip install this
import pyarrow.parquet as pq
import s3fs  # pip install this
from typing import List, Dict


def process_messages(messages: List[Dict]) -> pa.Table:
    records = [json.loads(message['body']) for message in messages]
    return pa.Table.from_pylist(records)


def write_to_s3(table: pa.Table, bucket: str, key: str) -> None:
    s3 = s3fs.S3FileSystem()
    with s3.open(f"s3://{bucket}/{key}", "wb") as f:
        pq.write_table(table, f)


def lambda_handler(event: Dict, context) -> Dict:
    """
    Lambda handler to process SQS messages and write to S3
    """
    # Environment variables
    BUCKET_NAME = os.environ['BUCKET_NAME']
    S3_PREFIX = os.environ['S3_PREFIX']

    try:
        # Get messages from event
        messages = event['Records']
        if not messages or len(messages) == 0:
            return {'statusCode': 200, 'message': 'No messages to process'}

        # Process messages
        table = process_messages(messages)

        # Generate S3 key with date and batch identifier
        timestamp = datetime.now().strftime('%Y%m%d')
        batch_id = context.aws_request_id
        s3_key = f"{S3_PREFIX}/{timestamp}/batch_{batch_id}.parquet"

        # Write to S3
        write_to_s3(table, BUCKET_NAME, s3_key)

        return {
            'statusCode': 200,
            'message': f'Successfully processed {len(messages)} messages',
            'output_location': f"s3://{BUCKET_NAME}/{s3_key}"
        }

    except Exception as e:
        print(f"Error processing messages: {str(e)}")
        raise e
